# Lantern Guide

Trim the wick and polish the lens.
